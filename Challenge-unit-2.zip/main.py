def withdraw (self):
  amount = float (input ("enter amount to be withdraw :"))
  if self.balance >= amount:
    self.balance= amount
  print("you withdraw:")
else
print ("insufficient balance:")
