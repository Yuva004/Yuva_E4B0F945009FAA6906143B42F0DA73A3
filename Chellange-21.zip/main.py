#Function to deposit amount
def deposit (self):
  amount = float (input ("enter amount to be deposited:"))
  self.balance += amount
  print ("\n amount deposited:",amount)